import UIKit

//Example of a call back

/*
Important to understand:
(String)->() // takes a String returns void
()->(String) // takes void returns a String
*/

func oddOrEven(number: Int, callbackFunction: (String) -> ()) {
    if number%2 == 0 {
        callbackFunction("Even")
    } else {
        callbackFunction("Odd")
    }
}

oddOrEven(number: 103) { stringValue -> () in
    print(stringValue)
}
