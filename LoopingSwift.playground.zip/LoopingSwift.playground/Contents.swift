import UIKit

/* Equivalent Loop in C
for (f = first; f <= last; f += interval)
{
    n += 1
}
*/

/* example values of your parameters 'first', 'last' and 'interval' */

let first = 0
let last = 10
let interval = 2

for f in stride(from: first, through: last, by: interval) {
    print(f)
}

print("---")

var number = 1
repeat {
    print(number)
    number += 1
} while number <= 10

