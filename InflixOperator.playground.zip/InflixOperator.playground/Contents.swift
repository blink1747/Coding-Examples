import UIKit

// Operator Overloading in Swift
//^ we will be using symbol in order to define the mathematical power.

// lhs ^ rhs : Example -> 2 ^ 2 = 2*2 =4
func ^(lhs: Double, rhs: Double) -> Double {
    return pow(lhs, rhs)
}

infix operator ^: AssignmentPrecedence
let x = 16.0 ^ 2.0
let y = 8.0 ^ 1/3

func ** (lhs: Double, rhs: Double) -> Double {
    return pow(lhs, rhs)
}

infix operator **: AssignmentPrecedence
let z = 4 ** 4 // 2^4
