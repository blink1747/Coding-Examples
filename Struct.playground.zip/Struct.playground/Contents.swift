import UIKit

/*
 Structs are value type:
 
 If you can always send a copy of your variable to other places, you never have to worry about that other place changing the value of your variable underneath you.
 
Since struct instances are allocated on stack, and class instances are allocated on heap, structs can sometimes be drastically faster.
 */

struct Point {
    var x : Double
    var y : Double
    
    func mag() -> Double {
        return pow(x*x + y*y, 0.5)
    }
}

let p = Point(x: 2, y: 2)
p.x
p.y
p.mag()



